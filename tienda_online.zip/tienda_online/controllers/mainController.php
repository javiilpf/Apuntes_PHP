<?php
    require_once("models/UserModel.php");
    require_once("models/UserRepository.php");


    session_start();

    if(isset($_GET['c'])){
        require_once('controllers/' . $_GET['c'] . 'Controller.php'); // controllers/ user
    }
    // cargar la vista
    // cargar la vista
    if(!isset($_SESSION['login'])){
        require_once 'views/loginView.phtml';
    }else{
        require_once("views/ListView.phtml");
    }

    if(isset($_POST['logout'])){

        // logout en $_session
        require_once 'views/LoginView.phtml';
    }


?>